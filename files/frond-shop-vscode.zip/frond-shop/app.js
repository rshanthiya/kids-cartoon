  // ---------- Product data ----------
  const PRODUCTS = [
    { id: 'monstera', name: 'Monstera Deliciosa', tag: 'Best seller', price: 42, category: 'Statement', desc: 'Big, glossy, split leaves. Grows fast toward any light you give it.', icon: 'leaf-split' },
    { id: 'snake', name: 'Snake Plant', tag: 'Nearly unkillable', price: 24, category: 'Low-light', desc: 'Thrives on neglect. Fine in a dim hallway for months at a time.', icon: 'leaf-spike' },
    { id: 'pothos', name: 'Golden Pothos', tag: 'Trailing', price: 18, category: 'Low-light', desc: 'Vines happily off a shelf. Cut and re-root a piece any time.', icon: 'vine' },
    { id: 'fiddle', name: 'Fiddle Leaf Fig', tag: 'Statement', price: 58, category: 'Statement', desc: 'Tall, dramatic, a little particular about being moved around.', icon: 'leaf-round' },
    { id: 'succulent', name: 'Succulent Trio', tag: 'Starter set', price: 22, category: 'Desk-size', desc: 'Three small pots, three shapes. Water once every couple weeks.', icon: 'succulent' },
    { id: 'zz', name: 'ZZ Plant', tag: 'Nearly unkillable', price: 30, category: 'Low-light', desc: 'Waxy, upright leaves. Handles forgetfulness better than most pets.', icon: 'leaf-spike' },
    { id: 'peace-lily', name: 'Peace Lily', tag: 'Flowering', price: 26, category: 'Flowering', desc: 'Tells you it needs water by drooping, then bounces right back.', icon: 'leaf-round' },
    { id: 'rubber', name: 'Rubber Plant', tag: 'Statement', price: 36, category: 'Statement', desc: 'Deep burgundy leaves, sturdy stem, grows into real height.', icon: 'leaf-split' },
    { id: 'succulent-desk', name: 'Single Desk Succulent', tag: 'Desk-size', price: 9, category: 'Desk-size', desc: 'A single small pot for a windowsill or a corner of a desk.', icon: 'succulent' },
  ];

  const ICONS = {
    'leaf-split': `<svg viewBox="0 0 100 100"><path d="M50 90 C50 60 20 55 15 20 C40 30 55 45 50 90 Z" fill="var(--teal)"/><path d="M50 90 C50 55 80 50 85 15 C60 28 45 45 50 90 Z" fill="var(--teal)" opacity="0.75"/></svg>`,
    'leaf-spike': `<svg viewBox="0 0 100 100"><path d="M40 90 L36 20 L48 35 Z" fill="var(--teal)"/><path d="M52 90 L50 12 L62 30 Z" fill="var(--teal)" opacity="0.85"/><path d="M64 90 L64 25 L74 40 Z" fill="var(--teal)" opacity="0.65"/></svg>`,
    'vine': `<svg viewBox="0 0 100 100"><path d="M20 20 C40 30 30 50 50 55 C70 60 60 80 80 85" stroke="var(--teal)" stroke-width="4" fill="none"/><circle cx="20" cy="20" r="7" fill="var(--teal)"/><circle cx="50" cy="55" r="8" fill="var(--teal)" opacity="0.8"/><circle cx="80" cy="85" r="7" fill="var(--teal)" opacity="0.6"/></svg>`,
    'leaf-round': `<svg viewBox="0 0 100 100"><ellipse cx="50" cy="55" rx="28" ry="34" fill="var(--teal)"/><line x1="50" y1="88" x2="50" y2="20" stroke="var(--bg)" stroke-width="2"/></svg>`,
    'succulent': `<svg viewBox="0 0 100 100"><circle cx="35" cy="60" r="18" fill="var(--teal)"/><circle cx="62" cy="55" r="14" fill="var(--teal)" opacity="0.75"/><circle cx="50" cy="35" r="12" fill="var(--teal)" opacity="0.6"/></svg>`,
  };

  // ---------- State ----------
  let cart = {};
  try {
    const saved = localStorage.getItem('frond-cart');
    if (saved) cart = JSON.parse(saved);
  } catch (e) { cart = {}; }

  let activeFilter = 'All';

  function saveCart() {
    try { localStorage.setItem('frond-cart', JSON.stringify(cart)); } catch (e) {}
  }

  // ---------- Rendering ----------
  function renderFilters() {
    const cats = ['All', ...new Set(PRODUCTS.map(p => p.category))];
    const el = document.getElementById('filters');
    el.innerHTML = cats.map(c =>
      `<button class="filter-btn ${c === activeFilter ? 'active' : ''}" onclick="setFilter('${c}')">${c}</button>`
    ).join('');
  }

  function setFilter(cat) {
    activeFilter = cat;
    renderFilters();
    renderGrid();
  }

  function renderGrid() {
    const list = activeFilter === 'All' ? PRODUCTS : PRODUCTS.filter(p => p.category === activeFilter);
    document.getElementById('result-count').textContent = `${list.length} plant${list.length === 1 ? '' : 's'}`;
    document.getElementById('product-grid').innerHTML = list.map(p => `
      <div class="card">
        <div class="card-art">${ICONS[p.icon]}</div>
        <div class="card-body">
          <span class="card-tag">${p.tag}</span>
          <span class="card-name">${p.name}</span>
          <span class="card-desc">${p.desc}</span>
          <div class="card-foot">
            <span class="card-price">$${p.price.toFixed(2)}</span>
            <button class="add-btn" id="add-${p.id}" onclick="addToCart('${p.id}')">Add to cart</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderCart() {
    const ids = Object.keys(cart);
    const container = document.getElementById('cart-items');
    const checkoutBtn = document.getElementById('checkout-btn');

    if (ids.length === 0) {
      container.innerHTML = `<div class="cart-empty">Your cart is empty.<br>Go pick out a plant.</div>`;
      document.getElementById('cart-total').textContent = '$0.00';
      document.getElementById('cart-count').textContent = '0';
      checkoutBtn.disabled = true;
      return;
    }

    let total = 0;
    let itemCount = 0;
    container.innerHTML = ids.map(id => {
      const p = PRODUCTS.find(x => x.id === id);
      const qty = cart[id];
      total += p.price * qty;
      itemCount += qty;
      return `
        <div class="cart-line">
          <div class="cart-line-art">${ICONS[p.icon]}</div>
          <div class="cart-line-info">
            <div class="cart-line-name">${p.name}</div>
            <div class="cart-line-price">$${p.price.toFixed(2)} each</div>
            <div class="qty-row">
              <button class="qty-btn" onclick="changeQty('${id}', -1)">−</button>
              <span class="qty-val">${qty}</span>
              <button class="qty-btn" onclick="changeQty('${id}', 1)">+</button>
              <button class="remove-link" onclick="removeItem('${id}')">Remove</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    document.getElementById('cart-total').textContent = `$${total.toFixed(2)}`;
    document.getElementById('cart-count').textContent = itemCount;
    checkoutBtn.disabled = false;
  }

  // ---------- Cart actions ----------
  function addToCart(id) {
    cart[id] = (cart[id] || 0) + 1;
    saveCart();
    renderCart();
    const btn = document.getElementById(`add-${id}`);
    if (btn) {
      btn.textContent = 'Added ✓';
      btn.classList.add('added');
      setTimeout(() => { btn.textContent = 'Add to cart'; btn.classList.remove('added'); }, 1000);
    }
  }

  function changeQty(id, delta) {
    if (!cart[id]) return;
    cart[id] += delta;
    if (cart[id] <= 0) delete cart[id];
    saveCart();
    renderCart();
  }

  function removeItem(id) {
    delete cart[id];
    saveCart();
    renderCart();
  }

  function openCart() {
    document.getElementById('cart-drawer').classList.add('open');
    document.getElementById('overlay').classList.add('open');
  }
  function closeCart() {
    document.getElementById('cart-drawer').classList.remove('open');
    document.getElementById('overlay').classList.remove('open');
  }

  // ---------- Checkout ----------
  function openCheckout() {
    const ids = Object.keys(cart);
    if (ids.length === 0) return;
    let total = 0;
    ids.forEach(id => { total += PRODUCTS.find(p => p.id === id).price * cart[id]; });

    document.getElementById('modal-content').innerHTML = `
      <h2>Checkout</h2>
      <p class="sub">Sample form — nothing is charged or sent anywhere.</p>
      <div class="field">
        <label for="ck-name">Full name</label>
        <input id="ck-name" type="text" placeholder="Jordan Rivera">
      </div>
      <div class="field">
        <label for="ck-email">Email</label>
        <input id="ck-email" type="email" placeholder="jordan@example.com">
      </div>
      <div class="field">
        <label for="ck-address">Shipping address</label>
        <input id="ck-address" type="text" placeholder="221B Baker Street">
      </div>
      <div class="field-row">
        <div class="field">
          <label for="ck-card">Card number</label>
          <input id="ck-card" type="text" placeholder="4242 4242 4242 4242" maxlength="19">
        </div>
        <div class="field" style="max-width:100px;">
          <label for="ck-cvc">CVC</label>
          <input id="ck-cvc" type="text" placeholder="123" maxlength="4">
        </div>
      </div>
      <div class="cart-total-row" style="margin-top:18px;"><span>Total due</span><strong>$${total.toFixed(2)}</strong></div>
      <div class="modal-actions">
        <button class="btn-ghost" onclick="closeModal()">Cancel</button>
        <button class="btn-primary" onclick="placeOrder(${total.toFixed(2)})">Place order</button>
      </div>
    `;
    document.getElementById('modal-overlay').classList.add('open');
  }

  function placeOrder(total) {
    const orderNum = 'FR-' + Math.floor(100000 + Math.random() * 900000);
    document.getElementById('modal-content').innerHTML = `
      <div class="confirm-icon">✓</div>
      <h2>Order placed</h2>
      <p class="sub">Confirmation <strong>${orderNum}</strong> for $${total} — this is a demo, so no plants are actually on the way.</p>
      <div class="modal-actions">
        <button class="btn-primary" style="width:100%;" onclick="finishOrder()">Done</button>
      </div>
    `;
    cart = {};
    saveCart();
    renderCart();
  }

  function finishOrder() {
    closeModal();
    closeCart();
  }

  function closeModal() {
    document.getElementById('modal-overlay').classList.remove('open');
  }

  // ---------- Init ----------
  renderFilters();
  renderGrid();
  renderCart();
